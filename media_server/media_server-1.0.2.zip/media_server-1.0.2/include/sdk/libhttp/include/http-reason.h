#ifndef _http_reason_h_
#define _http_reason_h_

const char* http_reason_phrase(int code);

#endif /* !_http_reason_h_ */
