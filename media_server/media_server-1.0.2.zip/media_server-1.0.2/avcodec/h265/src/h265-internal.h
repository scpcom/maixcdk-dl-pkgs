#ifndef _h265_internal_h_
#define _h265_internal_h_

#define sizeof_array(v) (sizeof(v) / sizeof((v)[0]))

#endif /* !_h265_internal_h_ */
