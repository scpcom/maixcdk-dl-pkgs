build from git@github.com:lxowalle/ireader.git

1.0.2 -> commit ee9a8ced8d68e398002fabb259956db9b521f873