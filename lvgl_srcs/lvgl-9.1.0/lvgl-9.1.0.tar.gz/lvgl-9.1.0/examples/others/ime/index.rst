
Pinyin IME 26 key input
-----------------------

.. lv_example:: others/ime/lv_example_ime_pinyin_1
  :language: c

Pinyin IME 9 key input
----------------------

.. lv_example:: others/ime/lv_example_ime_pinyin_2
  :language: c
