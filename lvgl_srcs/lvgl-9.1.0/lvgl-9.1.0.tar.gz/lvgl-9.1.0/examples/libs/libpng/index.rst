Open a PNG image from file
--------------------------

.. lv_example:: libs/libpng/lv_example_libpng_1
  :language: c

