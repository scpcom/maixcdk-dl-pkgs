Create a Barcode
----------------

.. lv_example:: libs/barcode/lv_example_barcode_1
  :language: c

