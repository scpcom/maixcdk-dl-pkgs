============
SDL renderer
============

API
---

:ref:`lv_draw_sdl`

:ref:`lv_draw_sdl_composite`

:ref:`lv_draw_sdl_img`

:ref:`lv_draw_sdl_layer`

:ref:`lv_draw_sdl_mask`

:ref:`lv_draw_sdl_priv`

:ref:`lv_draw_sdl_rect`

:ref:`lv_draw_sdl_stack_blur`

:ref:`lv_draw_sdl_texture_cache`

:ref:`lv_draw_sdl_utils`
